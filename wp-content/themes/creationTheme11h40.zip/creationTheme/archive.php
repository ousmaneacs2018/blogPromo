<?php the_excerpt(); ?>
